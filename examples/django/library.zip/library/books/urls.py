from django.urls import path
from .views import (
    author_list as books_author_list,
    author_detail as books_author_detail,
    author_create as books_author_create,
    author_edit as books_author_edit,
    author_delete as books_author_delete,
)
from .views import book_list, book_detail, book_create, book_edit, book_delete
from .views import publisher_list, publisher_detail, publisher_create, publisher_edit, publisher_delete
from .views import magazine_list, magazine_detail, magazine_create, magazine_edit, magazine_delete


urlpatterns = [
    path('authors/', books_author_list, name='author_list'),
    path('authors/<int:pk>/', books_author_detail, name='author_detail'),
    path('authors/create/', books_author_create, name='author_create'),
    path('authors/<int:pk>/edit/', books_author_edit, name='author_edit'),
    path('authors/<int:pk>/delete/', books_author_delete, name='author_delete'),
    path('books/', book_list, name='book_list'),
    path('books/<int:pk>/', book_detail, name='book_detail'),
    path('books/create/', book_create, name='book_create'),
    path('books/<int:pk>/edit/', book_edit, name='book_edit'),
    path('books/<int:pk>/delete/', book_delete, name='book_delete'),
    path('publishers/', publisher_list, name='publisher_list'),
    path('publishers/<int:pk>/', publisher_detail, name='publisher_detail'),
    path('publishers/create/', publisher_create, name='publisher_create'),
    path('publishers/<int:pk>/edit/', publisher_edit, name='publisher_edit'),
    path('publishers/<int:pk>/delete/', publisher_delete, name='publisher_delete'),
    path('magazines/', magazine_list, name='magazine_list'),
    path('magazines/<int:pk>/', magazine_detail, name='magazine_detail'),
    path('magazines/create/', magazine_create, name='magazine_create'),
    path('magazines/<int:pk>/edit/', magazine_edit, name='magazine_edit'),
    path('magazines/<int:pk>/delete/', magazine_delete, name='magazine_delete'),
]
